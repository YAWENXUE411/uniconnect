create function st_pixelascentroid(rast raster, x integer, y integer) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT ST_Centroid(geom) FROM _st_pixelaspolygons($1, NULL, $2, $3)
$$;

comment on function st_pixelascentroid(raster, integer, integer) is 'args: rast, columnx, rowy - Returns the centroid (point geometry) of the area represented by a pixel.';

alter function st_pixelascentroid(raster, integer, integer) owner to postgres;

