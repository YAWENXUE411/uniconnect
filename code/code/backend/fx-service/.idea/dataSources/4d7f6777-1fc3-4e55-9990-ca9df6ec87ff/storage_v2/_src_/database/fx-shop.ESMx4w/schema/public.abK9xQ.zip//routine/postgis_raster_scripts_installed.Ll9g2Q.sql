create function postgis_raster_scripts_installed() returns text
    immutable
    language sql
as
$$
SELECT '2.2.2'::text || ' r' || 14797::text AS version
$$;

alter function postgis_raster_scripts_installed() owner to postgres;

