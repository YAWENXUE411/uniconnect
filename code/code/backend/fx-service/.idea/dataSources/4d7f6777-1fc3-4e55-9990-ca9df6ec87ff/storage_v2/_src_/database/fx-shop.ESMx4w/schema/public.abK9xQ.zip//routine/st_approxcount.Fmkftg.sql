create function st_approxcount(rast raster, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true, sample_percent double precision DEFAULT 0.1) returns bigint
    immutable
    strict
    language sql
as
$$
SELECT _st_count($1, $2, $3, $4)
$$;

alter function st_approxcount(raster, integer, boolean, double precision) owner to postgres;

