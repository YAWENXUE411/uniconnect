create function st_polyfromtext(text, integer) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT CASE WHEN geometrytype(ST_GeomFromText($1, $2)) = 'POLYGON'
	THEN ST_GeomFromText($1, $2)
	ELSE NULL END

$$;

alter function st_polyfromtext(text, integer) owner to postgres;

