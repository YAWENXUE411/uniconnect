create function st_approxquantile(rast raster, sample_percent double precision, quantile double precision) returns double precision
    immutable
    strict
    language sql
as
$$
SELECT (_st_quantile($1, 1, TRUE, $2, ARRAY[$3]::double precision[])).value
$$;

alter function st_approxquantile(raster, double precision, double precision) owner to postgres;

