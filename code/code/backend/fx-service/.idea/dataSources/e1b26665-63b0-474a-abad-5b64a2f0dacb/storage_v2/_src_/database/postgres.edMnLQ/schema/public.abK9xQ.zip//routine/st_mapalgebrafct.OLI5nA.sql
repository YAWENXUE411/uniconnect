create function st_mapalgebrafct(rast raster, band integer, onerastuserfunc regprocedure) returns raster
    language sql
as
$$
SELECT st_mapalgebrafct($1, $2, NULL, $3, NULL)
$$;

alter function st_mapalgebrafct(raster, integer, regprocedure) owner to postgres;

