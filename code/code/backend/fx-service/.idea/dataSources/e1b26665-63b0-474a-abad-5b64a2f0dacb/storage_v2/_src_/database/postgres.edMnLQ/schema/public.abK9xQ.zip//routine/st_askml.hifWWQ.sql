create function st_askml(text) returns text
    immutable
    strict
    language sql
as
$$
SELECT _ST_AsKML(2, $1::geometry, 15, null);
$$;

alter function st_askml(text) owner to postgres;

